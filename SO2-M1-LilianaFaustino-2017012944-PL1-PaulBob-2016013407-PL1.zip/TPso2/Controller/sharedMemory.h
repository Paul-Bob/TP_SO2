#ifndef SHAREDMEM_H
#define SHAREDMEM_H

#include "../HF/structs.h"
int createMap(pDATA data);
int createAirportSpace(pDATA data);
int createAirplaneSpace(pDATA data);
int createProducerConsumer(pDATA data);

#endif

