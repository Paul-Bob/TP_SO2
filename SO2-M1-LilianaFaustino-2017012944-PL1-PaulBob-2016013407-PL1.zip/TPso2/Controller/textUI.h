#ifndef COMANDOSCONTROLADOR_H
#define COMANDOSCONTROLADOR_H

#include "../HF/structs.h"

void interpretaComandoControlador(TCHAR* command, pDATA data);

#endif
