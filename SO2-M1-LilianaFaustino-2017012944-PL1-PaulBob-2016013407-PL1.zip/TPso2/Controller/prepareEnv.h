#ifndef PREPARACAO_H
#define PREPARACAO_H

int prepareEnvironment(TCHAR* path);
int getMax(TCHAR* attribute, TCHAR* path);

#endif // !PREPARACAO_H
